# Sample Visual Studio Extension Using WebView View

## Features

Visual Studio Code Sample extension developed to showcase WebView views using WebView API.This extension will be displayed
in activity bar of VS Code editor, the Sidebar of VS Code editor will have one view loaded with custom UI (Html)

## Requirements

No requirements to build tis project. Clone from GIT and do npm install


## Release Notes

Sample extension

### 1.0.0

Initial release

-----------------------------------------------------------------------------------------------------------
## Following extension guidelines

Ensure that you've read through the extensions guidelines and follow the best practices for creating your extension.

* [Extension Guidelines](https://code.visualstudio.com/api/references/extension-guidelines)